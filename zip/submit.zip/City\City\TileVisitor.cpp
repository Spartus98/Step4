/**
 * \file TileVisitor.cpp
 *
 * \author Zach Fincher
 *
 * Base for any tile visitor
 */

#include "pch.h"
#include "TileVisitor.h"
